import pygame
from copy import deepcopy
from checkers.constantes import PLAYER

#MINIMAX
def minimax_alg (node, depth,f_cost, minimax = False):
    win = node.winner()
    if depth == 0 or win !=0:
        return node.evaluate(win,depth,f_cost), node
    if minimax: #minimax = TRUE => minimizar
        moves = get_all_moves(node, PLAYER[0])
        if moves:
            best_move = None
            min_eval = float('inf')
            for move in moves:
                value = minimax_alg(move,depth-1,f_cost,False)[0]
                if value<min_eval:
                    min_eval = value
                    best_move = move
            return min_eval,best_move
        else:
            return node.evaluate(win,depth,f_cost),node
    else: #minimax = FALSE => maximizar
        moves = get_all_moves(node, PLAYER[1])
        if moves:
            best_move = None
            max_eval = float('-inf')
            for move in moves:
                value = minimax_alg(move,depth-1,f_cost,True)[0]
                if value>max_eval:
                    max_eval = value
                    best_move = move
            return max_eval,best_move
        else:
            return node.evaluate(win,depth,f_cost),node
            
#Alpha-Beta pruning
def alpha_beta_pruning(node, depth, f_cost,minimax = False, alpha = float('-inf'), beta = float('inf')):
    win = node.winner()
    if depth == 0 or win !=0:
        return node.evaluate(win,depth,f_cost), node

    if minimax: #minimax = TRUE => minimizar
        aux = 1
        best_move = None
        min_eval = float('inf')
        for piece in node.get_all_pieces(PLAYER[0]):
            valid_moves = node.get_valid_moves(piece)
            if valid_moves:
                aux += 1
                for move, skip in valid_moves.items():
                    temp_board = deepcopy(node)
                    temp_piece = temp_board.get_piece(piece.row, piece.col)
                    new_node = simulate_move(temp_piece,move,temp_board, skip)
                    value = alpha_beta_pruning(new_node,depth-1,f_cost,False,alpha,beta)[0]
                    if value<min_eval:
                        min_eval = value
                        best_move = new_node
                        beta = min(min_eval,beta)
                    if alpha>=beta:
                        return min_eval,best_move
        if aux>1:
            return min_eval,best_move
        else:
            return node.evaluate(win,depth,f_cost),node
    else: #minimax = FALSE => maximizar
        aux = 1
        best_move = None
        max_eval = float('-inf')
        for piece in node.get_all_pieces(PLAYER[1]):
            valid_moves = node.get_valid_moves(piece)
            if valid_moves:
                aux += 1
                for move, skip in valid_moves.items():
                    temp_board = deepcopy(node)
                    temp_piece = temp_board.get_piece(piece.row, piece.col)
                    new_node = simulate_move(temp_piece,move,temp_board, skip)
                    value = alpha_beta_pruning(new_node,depth-1,f_cost,True,alpha,beta)[0]
                    if value>max_eval:
                        max_eval = value
                        best_move = new_node
                        alpha = max(max_eval,alpha)
                    if alpha>=beta:
                        return max_eval,best_move
        if aux>1:
            return max_eval,best_move
        else:
            return node.evaluate(win,depth,f_cost),node
#Simular movimiento y crear un nuevo tablero
def simulate_move (piece, move, board, skip):
    board.move(piece,move[0],move[1])
    if skip:
        board.remove(skip)
    return board

#Metodo para generar todos los movimientos
def get_all_moves(board, color):
    moves = []

    for piece in board.get_all_pieces(color):
        valid_moves = board.get_valid_moves(piece)
        for move, skip in valid_moves.items():
            temp_board = deepcopy(board)
            temp_piece = temp_board.get_piece(piece.row, piece.col)
            new_board = simulate_move(temp_piece,move,temp_board, skip)
            moves.append(new_board)
    return moves

