#Importamos los modulos necesarios
import pygame
import time
import sys
from checkers.constantes import *
from checkers.game import Game
from algoritmos import alpha_beta_pruning,minimax_alg


# Posición del mouse
def get_pos_from_mouse(pos):
    x,y= pos
    row= y // SQUARE_SIZE
    col= x// SQUARE_SIZE
    return row, col

#Método para iniciar el juego
def main(depth=1,dificultad="Nada",f_cost=3):
    #Inicializamos la ventana
    WIN = pygame.display.set_mode((WW, WH))
    FPS = 30
    #Titulo de la ventana
    pygame.display.set_caption('Damas')
    run=True
    winner = False
    #determinar fps
    clock=pygame.time.Clock()

    game=Game(WIN)
    ai_move_time = None
    #event LOOP
    while run:
        clock.tick(FPS)
        #Si no ha ganado nadie
        if game.winner()== 0:
            if game.turn == RED:
                start = time.time()
                #value,new_board = minimax_alg(game.get_board(),2,f_cost) sirve para hacer comparaciones de tiempo
                value_red, new_board_red = alpha_beta_pruning(game.get_board(),depth,f_cost)
                game.ai_move(new_board_red)
                end = time.time()
                ai_move_time = round(end-start,5)
                print("RED: ",ai_move_time,value_red)
            #Descomentar este else cuando queremos poner a competir dos IA 
            # else:
            #     start = time.time()
            #     value_black, new_board_black = alpha_beta_pruning(game.get_board(),5,2,True)
            #     game.ai_move(new_board_black)
            #     end =  time.time()
            #     ai_move_time = round(end-start,5)
            #     print("BLACK: ",ai_move_time,value_black)

            #Para cada evento 
            for event in pygame.event.get():
                #Si tachamos la ventana
                if event.type == pygame.QUIT:
                    run=False
                #Evento cuando se da click en la ventana
                if event.type == pygame.MOUSEBUTTONDOWN:
                    pos = pygame.mouse.get_pos()
                    row, col= get_pos_from_mouse(pos)
                    #Si esta en el tablero muestra movimientos validos
                    if (row <=7 and row >=0 and col <=7 and col >=0):
                        game.select(row, col)
            #Actualiza el display de la ventana
            game.update(ai_move_time,dificultad,depth,f_cost)
        else:
            #Si ya ganó alguien se muestra quién ganó
            pygame.draw.rect(WIN, RED,(45, 95, 310, 210))
            pygame.draw.rect(WIN, BLACK,(50, 100, 300, 200))
            font = pygame.font.Font('freesansbold.ttf',25)
            text = font.render("GANADOR:",True,WHITE)
            WIN.blit(text, (128, 130))
            if game.winner()<0:
                text3 = font.render("FICHAS NEGRAS",True,WHITE)
            else:
                text3 = font.render("FICHAS ROJAS",True,WHITE)
            WIN.blit(text3,(110,200))
            font = pygame.font.Font('freesansbold.ttf',15)
            text2 = font.render("Da click para continuar",True,WHITE)
            WIN.blit(text2, (115, 250))
            pygame.display.update()
            #Cuando se dé click en la ventana se pasa al menú
            while not winner:
                for event in pygame.event.get():
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        winner = True
            run = False
    return run