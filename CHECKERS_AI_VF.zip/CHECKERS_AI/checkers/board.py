import pygame
from .constantes import *
from .piezas import Piece

class Board:

    def __init__(self):
        self.board = [] #Tablero
        self.red_left = self.black_left = 12 #Número inicial de fichas
        self.red_damas = self.black_damas = 0 #Número inicial de damas
        self.red_safe = self.black_safe = 0 #Número de fichas que no se pueden capturar
        self.full_skipped = [] #parametro auxiliar para que no truene esta cosa
        self.create_board()

    def draw_sq(self,win,dificultad,depth,h):
        win.fill(CAFE,(0,0,WIDTH,HEIGHT)) #se pone todo el tablero en cafe
        win.fill(WHITE,(WIDTH+4,0,WW-WIDTH-4,WH))
        win.fill(WHITE,(0,HEIGHT+4,WW,WH-HEIGHT-4))
        text1 = FONT.render("Dificultad:",True,(0,0,0))
        text2 = FONT.render("Profundidad:",True,(0,0,0))
        text3 = FONT.render("Función de Costos:",True,(0,0,0))
        win.blit(text1,(460,50))
        win.blit(FONT.render(str(dificultad),True,(0,0,0)),(475,70))
        win.blit(text2,(450,120))
        win.blit(FONT.render(str(depth),True,(0,0,0)),(490,140))
        win.blit(text3,(430,180))
        font = pygame.font.Font('freesansbold.ttf',11)
        pygame.font.Font.set_italic(font,True)
        text4 = font.render("Now playing: music for playing checkers w the homies",True,BLACK)
        win.blit(text4,(53,480))
        if h == 1:
            win.blit(FONT.render("- Piezas restantes",True,(0,0,0)),(440,200))
            win.blit(FONT.render("- Posición ganadora",True,(0,0,0)),(440,220))
        elif h == 2:
            win.blit(FONT.render("- Piezas restantes",True,(0,0,0)),(440,200))
            win.blit(FONT.render("- Damas restantes",True,(0,0,0)),(440,220))
            win.blit(FONT.render("- Piezas seguras",True,(0,0,0)),(440,240))
            win.blit(FONT.render("- Posición ganadora",True,(0,0,0)),(440,260))
            win.blit(FONT.render("con profunidad",True,(0,0,0)),(450,275))
        #Creamos el patrón de "una y una" para los colores en el tablero
        for row in range(ROWS):
            for col in range(row % 2, COLS, 2): 
                pygame.draw.rect(win, LCAFE, (row*SQUARE_SIZE, col*SQUARE_SIZE, SQUARE_SIZE, SQUARE_SIZE))
        pygame.draw.line(win,(0,0,0),(WIDTH+2,0),(WIDTH+2,HEIGHT+4),4)
        pygame.draw.line(win,(0,0,0),(0,HEIGHT+2),(WIDTH+4,HEIGHT+2),4)

    
    def get_piece(self, row, col):
        return self.board[row][col]

    # Indicar donde hay fichas y donde no
    def create_board(self):
        for row in range(ROWS):
            self.board.append([])
            for col in range(COLS):
                if col % 2 == ((row + 1) % 2):
                    if row < 3:
                        self.board[row].append(Piece(row, col, RED))
                        if row == 0 or row == 7 or col == 0 or col == 7:
                            self.red_safe +=1
                    elif row > 4:
                        self.board[row].append(Piece(row,col, BLACK))
                        if row == 0 or row == 7 or col == 0 or col == 7:
                            self.black_safe +=1
                    else:
                        self.board[row].append(0) #cuadro vacío 
                else:
                    self.board[row].append(0)
    
    #Mover fichas,cambiar a dama, calcular piezas seguras
    def move(self, piece, row, col):
        self.board[piece.row][piece.col], self.board[row][col]= self.board[row][col], self.board[piece.row][piece.col]
        piece.move(row, col)

        if not piece.dama:
            if row == ROWS - 1 or row == 0:
                piece.def_dama()

                if piece.color == BLACK:
                    self.black_damas +=1
                else:
                    self.red_damas +=1
        if piece.row == 0 or piece.row == 7 or piece.col == 0 or piece.col == 7:
            if piece.safe == False:
                if piece.color == BLACK:
                    self.black_safe += 1
                else:
                    self.red_safe += 1
                piece.is_safe()
        else:
            if piece.safe == True:
                if piece.color == BLACK:
                    self.black_safe -= 1
                else:
                    self.red_safe -= 1
                piece.not_safe()

    #Dibujar las piezas y el tablero
    def draw(self, win,dificultad,depth,h):
        self.draw_sq(win,dificultad,depth,h)

        for row in range(ROWS):
            for col in range(COLS):
                piece= self.board[row][col]

                if piece !=0:
                    piece.draw(win)

    #Función para obtener lo movimientos válidos
    def get_valid_moves(self, piece):
        moves = {}
        left = piece.col - 1
        right= piece.col + 1
        row = piece.row

        if piece.color == BLACK or piece.dama:
            moves.update(self._traverse_left(row - 1, -1, piece.color, left, piece))
            moves.update(self._traverse_right(row - 1, -1, piece.color, right, piece))
        
        if piece.color == RED or piece.dama:
            moves.update(self._traverse_left(row +1, 1, piece.color, left,piece))
            moves.update(self._traverse_right(row +1, 1, piece.color, right,piece))
        self.full_skipped = []
        return moves
    
    #Movimiento hacia la izquierda
    def _traverse_left(self, mov, step, color, left, piece, skipped=[],last=[]):
        moves={}
        if left >= 0 and mov>=0 and mov < ROWS:
            current = self.board[mov][left]
            if not (current in self.full_skipped):
                if current == piece:
                    moves[(mov, left)]= skipped + last
                elif current == 0:
                    if skipped and not last:
                        return moves
                    elif last:
                        skipped = skipped + last
                        moves[(mov, left)]= skipped
                        self.full_skipped.append(last[0])
                        if piece.dama:
                            if step == -1:
                                moves.update(self._traverse_left(mov+step, step, color, left-1, piece, skipped))
                                moves.update(self._traverse_right(mov+step, step, color, left+1, piece, skipped))
                                step = -step
                                moves.update(self._traverse_left(mov+step, step, color, left+1, piece, skipped))
                            else:
                                moves.update(self._traverse_left(mov+step, step, color, left-1, piece, skipped))
                                moves.update(self._traverse_right(mov+step, step, color, left+1, piece, skipped))
                                step = -step
                                moves.update(self._traverse_left(mov+step, step, color, left-1, piece, skipped))
                        else:
                            moves.update(self._traverse_left(mov+step, step, color, left-1, piece, skipped))
                            moves.update(self._traverse_right(mov+step, step, color, left+1, piece,  skipped))
                    else:
                        moves[(mov, left)]= current
                elif current.color == color or last:
                    return moves
                else:
                    last = [current]
                    moves.update(self._traverse_left(mov+step, step, color, left-1, piece, skipped,last))
        return moves
    #Movimiento hacia la derecha
    def _traverse_right(self, mov, step, color, right, piece, skipped=[], last =[]):
        moves={}
        if right < COLS and mov>=0 and mov < ROWS:
            current = self.board[mov][right]
            if not (current in self.full_skipped):
                if current == piece:
                    moves[(mov, right)]= skipped + last
                elif current == 0:
                    if skipped and not last:
                        return moves
                    elif last:
                        skipped = skipped + last
                        moves[(mov, right)]= skipped
                        self.full_skipped.append(last[0])
                        if piece.dama:
                            if step == -1:
                                moves.update(self._traverse_left(mov+step, step, color, right-1, piece, skipped))
                                moves.update(self._traverse_right(mov+step, step, color, right+1, piece, skipped))
                                step = -step
                                moves.update(self._traverse_right(mov+step, step, color, right-1, piece, skipped))
                            else:
                                moves.update(self._traverse_left(mov+step, step, color, right-1, piece, skipped))
                                moves.update(self._traverse_right(mov+step, step, color, right+1, piece, skipped))
                                step = -step
                                moves.update(self._traverse_right(mov+step, step, color, right-1, piece, skipped))
                        else:
                            moves.update(self._traverse_left(mov+step, step, color, right-1, piece, skipped))
                            moves.update(self._traverse_right(mov+step, step, color, right+1, piece,  skipped))
                    else:
                        moves[(mov, right)]= current
                elif current.color == color or last:
                    return moves
                else:
                    last = [current]
                    moves.update(self._traverse_right(mov+step, step, color, right+1, piece, skipped,last))
        return moves

    #Función para quitar las piezas saltadas
    def remove(self, pieces):
        for piece in pieces:
            self.board[piece.row][piece.col] = 0
            if piece != 0:
                if piece.color == RED:
                    self.red_left -= 1
                    if piece.dama:
                        self.red_damas -= 1
                else:
                    self.black_left -= 1
                    if piece.dama:
                        self.black_damas -= 1
    #Ganador
    def winner (self):
        k = 0
        if self.red_left <= 0:
            k = -10000
        elif self.black_left <= 0:
            k = 10000
        return k
    
    #Heuristica
    def evaluate (self,win,depth,f_cost):
        redL = self.red_left
        blackL = self.black_left
        if f_cost == 1:
            if win == 0:
                return redL - blackL
            else:
                return win
        else:
            damasR = self.red_damas
            damasB = self.black_damas
            if win == 0:
                return (redL + damasR*0.6 + self.red_safe*0.2) - (blackL + damasB*0.6 + self.black_safe*0.2)
            else:
                return win*(depth+1)
    
    #Obtener todas las piezas de un determinado color
    def get_all_pieces(self,color):
        pieces = []
        for row in self.board:
            for piece in row:
                if piece != 0 and piece.color == color:
                    pieces.append(piece)
        return pieces