import pygame

pygame.init()
#Board Size
WIDTH, HEIGHT= 400, 400
#Window Size
WW,WH = 600,500
#Tablero
ROWS, COLS= 8, 8
#Tamaño del cuadrado
SQUARE_SIZE= WIDTH//COLS
#Colores
CAFE = (128, 64, 0)
LCAFE = (238, 208, 157)
BLACK=(0,0,0)
RED = (255,0,0)
BLUE = (0,32,255)
GREY=(128, 128, 128)
WHITE = (255,255,255)

EASY=(184, 239, 126)
EASY_H=(85, 143, 25)
MEDIUM=(237, 239, 66)
MEDIUM_H=(215, 217, 18)
HARD=(246, 113, 93)
HARD_H=(241, 50, 22)

PLAYER = [BLACK, RED]
FONT = pygame.font.Font('freesansbold.ttf',15)
#La corona para que distingamos una dama de una ficha normal
CROWN = pygame.transform.scale(pygame.image.load('assets/crown.png'), (44, 25))
CHECKERS_w_HOMIES='assets/checkers_with_homies.mp3'
