#Archivo para la lógica del juego
import pygame
from .board import Board
from .constantes import *

class Game:
    def __init__(self, win):
        self._init()
        self.win = win

    def update(self,time,dificultad,depth,h):
        self.board.draw(self.win,dificultad,depth,h)
        self.draw_valid_moves(self.valid_moves)
        if self.turn == BLACK:
            text = FONT.render("Es tu turno: mueve una ficha",True,(0,0,0))
            self.win.blit(text,(90,420))
            if time!= None:
                text = FONT.render("Tiempo de respuesta",True,(0,0,0))
                self.win.blit(text,(428,320))
                self.win.blit(FONT.render("de la IA:",True,(0,0,0)),(472,340))
                text = FONT.render(str(time) + " segundos",True,(0,0,0))
                self.win.blit(text,(443,360))
        pygame.display.update()

    def reset(self):
        self._init()

    def _init(self):
        self.selected= None
        self.board= Board()
        self.turn= BLACK
        self.valid_moves= {}

    
    def select(self, row, col,i):
        if self.selected:
            result = self._move(row, col)

            if not result:
                self.selected= None
                self.select(row,col,i)
            else:
                i +=1
                
        piece = self.board.get_piece(row, col)

        if piece!=0 and piece.color==self.turn:
            self.selected = piece
            self.valid_moves = self.board.get_valid_moves(piece)
            return True,i

        return False,i   

    def _move(self, row, col):
        piece = self.board.get_piece(row, col)
        piece_obj = self.selected
        all_pieces = self.board.get_all_pieces(piece_obj.color)
        if not(self.valid_moves) and all_pieces[0]==piece_obj and len(all_pieces)==1:
            self.change_turn()
        else:
            if piece_obj and (row, col) in self.valid_moves:
                self.board.move(self.selected, row, col)
                skipped=self.valid_moves[(row, col)]

                if skipped:
                    self.board.remove(skipped)
                self.change_turn()
            else:
                return False
        return True


    def change_turn(self):
        self.valid_moves= {}
        if self.turn == BLACK:
            self.turn = RED
        else:
            self.turn = BLACK

    def draw_valid_moves(self, moves):
        for move in moves:
            row, col= move

            pygame.draw.circle(self.win, BLUE, (col*SQUARE_SIZE + SQUARE_SIZE//2, row*SQUARE_SIZE + SQUARE_SIZE//2), 10)

    def winner (self):
        return self.board.winner()

    def get_board(self):
        return self.board

    def ai_move(self, board):
        self.board = board
        self.change_turn()