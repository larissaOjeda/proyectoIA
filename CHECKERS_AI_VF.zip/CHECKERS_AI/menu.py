import pygame
import principal
from checkers.game import Game
import os
from checkers.constantes import *
#Inicializamos la ventana
pygame.init()
#Ponemos la música de fondo
pygame.mixer.init()
pygame.mixer.music.load(CHECKERS_w_HOMIES)
pygame.mixer.music.play(-1)
pygame.mixer.music.set_volume(0.25)

#Se declaran los elementos de la ventana: texto y botones
screen = pygame.display.set_mode((WIDTH, HEIGHT -20))
pygame.display.set_caption("Nivel de dificultad: DAMAS")
title_space = pygame.draw.rect(screen,(0,0,0),(20,20,100,50))
font = pygame.font.Font('freesansbold.ttf',20)
text = font.render("Escoge el nivel de dificultad",True,(255,255,255))
font = pygame.font.Font('freesansbold.ttf',11)
pygame.font.Font.set_italic(font,True)
text2 = font.render("Now playing: music for playing checkers w the homies",True,(255,255,255))
screen.blit(text,(title_space.centerx-11,title_space.centery-8))
screen.blit(text2,(64,350))

#Para volver a visualizar el menu
def start():
    screen = pygame.display.set_mode((WIDTH, HEIGHT -20))
    pygame.display.set_caption("Nivel de dificultad: DAMAS")
    title_space = pygame.draw.rect(screen,(0,0,0),(20,20,100,50))
    font = pygame.font.Font('freesansbold.ttf',20)
    text = font.render("Escoge el nivel de dificultad",True,(255,255,255))
    font = pygame.font.Font('freesansbold.ttf',11)
    pygame.font.Font.set_italic(font,True)
    text2 = font.render("Now playing: music for playing checkers w the homies",True,(255,255,255))
    screen.blit(text,(title_space.centerx-11,title_space.centery-8))
    screen.blit(text2,(64,350))

#Para crear botones
def button(msg, x, y, w, h, color_i, color_h, ):
    mouse=  pygame.mouse.get_pos()

    if (x+w > mouse[0] > x) and (y+h > mouse[1] > y):
        pygame.draw.rect(screen, color_h, (x,y,w,h))
    else:
        pygame.draw.rect(screen, color_i, (x,y,w,h))
    
    font = pygame.font.Font('freesansbold.ttf',15)
    text = font.render(msg,True,(0,0,0))
    screen.blit(text, ((x+(w/2)-22), (y+(h/2)-8)))

button("Fácil", 150, 90, 100, 50, EASY, EASY_H)
button("Medio", 150, 160, 100, 50, MEDIUM, MEDIUM_H)
button("Difícil", 150, 230, 100, 50, HARD, HARD_H)

pygame.display.flip()

def menu():
    menuActivo = True
    while menuActivo:
        #Cambio de color
        pygame.display.update()
        button("Fácil", 150, 90, 100, 50, (119, 249, 45), (64, 156, 12))
        button("Medio", 150, 160, 100, 50, (232, 240, 67), (218, 201, 29))
        button("Difícil", 150, 230, 100, 50, (245, 68, 60), (255, 12, 0))

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT: #se cierra la ventana
                menuActivo = False
            if evento.type == pygame.MOUSEBUTTONDOWN: #cuandos se da click
                x,y = pygame.mouse.get_pos()
                if x >= 150 and x <= 250:
                    if y >= 90 and y <= 140:
                        principal.main(1,"Fácil",1)
                        start()
                    elif y >= 160 and y <= 210 :
                        principal.main(3,"Medio",2)
                        start()
                    elif y >= 230 and y <= 280:
                        principal.main(6,"Difícil",2)
                        start()                  
menu()