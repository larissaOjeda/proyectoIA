import pygame
from copy import deepcopy
from checkers.constantes import PLAYER

def negamax (node, depth, game, i = 1, alpha = float('inf'), beta = float('-inf')):
    if depth == 0 or node.winner() != 0:
        return node.evaluate(), node
    moves = get_all_moves(node, PLAYER[i], game)
    if moves:
        best_move = None
        for move in moves:
            value = negamax(move[0], depth-1, game, not i, alpha = -beta, beta = -alpha)[0]
            if (-value)> beta:
                beta = -value
                best_move = move[0]
            if beta >= alpha:
                return beta, best_move
        return beta, best_move
    else:
        return node.evaluate(),node


def simulate_move (piece, move, board, game, skip):
    board.move(piece,move[0],move[1])
    if skip:
        board.remove(skip)
    return board

def get_all_moves(board, color, game):
    moves = []

    for piece in board.get_all_pieces(color):
        valid_moves = board.get_valid_moves(piece)
        for move, skip in valid_moves.items():
            temp_board = deepcopy(board)
            temp_piece = temp_board.get_piece(piece.row, piece.col)
            new_board = simulate_move(temp_piece,move,temp_board, game, skip)
            moves.append([new_board,piece])
    return moves





