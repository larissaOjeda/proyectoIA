import pygame

#Window Size
WIDTH, HEIGHT= 400, 400
#Tablero
ROWS, COLS= 8, 8
#Tamaño del cuadrado
SQUARE_SIZE= WIDTH//COLS
#Colores
CAFE = (128, 64, 0)
LCAFE = (238, 208, 157)
BLACK=(0,0,0)
RED = (255,0,0)
BLUE = (0,32,255)
GREY=(128, 128, 128)
PLAYER = [BLACK, RED]
#La corona para que distingamos una dama de una ficha normal
CROWN = pygame.transform.scale(pygame.image.load('assets/crown.png'), (44, 25))
