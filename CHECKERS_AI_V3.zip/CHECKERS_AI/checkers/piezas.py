from .constantes import *

class Piece:
    PADDING = 5
    BORDER = 1

    def __init__(self, row, col, color):
        self.row= row
        self.col= col
        self.color= color
        self.dama= False

        if self.color==RED:
            self.direction= -1 #provisional
        else:
             self.direction= 1

        self.x=0
        self.y=0
        self.calc_position()
    #Posición de la pieza
    def calc_position(self):
        self.x = SQUARE_SIZE * self.col + SQUARE_SIZE//2
        self.y = SQUARE_SIZE * self.row + SQUARE_SIZE//2

    #Cambiar a dama
    def def_dama(self):
        self.dama=True

    #Dibujar la pieza
    def draw(self,win):
        radio = SQUARE_SIZE//2 - self.PADDING

        pygame.draw.circle(win, GREY, (self.x, self.y), radio + self.BORDER)
        pygame.draw.circle(win, self.color, (self.x, self.y), radio)

        if self.dama:
            win.blit(CROWN, (self.x - CROWN.get_width()//2, self.y - CROWN.get_height()//2))

    #Método para "mover" la pieza
    def move(self, row, col):
        self.row=row
        self.col=col
        self.calc_position()

    

