import pygame
from copy import deepcopy
from checkers.constantes import PLAYER

def negamax (node, depth, game, i = 1, alpha = float('inf'), beta = float('-inf')):
    win = node.winner()
    if depth == 0 or win != 0:
        return node.evaluate(win), node
    moves = get_all_moves(node, PLAYER[i], game)
    if moves:
        best_move = None
        for move in moves:
            value = -negamax(move[0], depth-1, game, not i, alpha = -beta, beta = -alpha)[0]
            if value> beta:
                beta = value
                best_move = move[0]
            if beta >= alpha:
                return beta, best_move
        return beta, best_move
    else:
        return node.evaluate(win),node

def alpha_beta_pruning (node, depth, game, minimax = False, alpha = float('-inf'), beta = float('inf')):
    win = node.winner()
    if depth == 0 or win !=0:
        return node.evaluate(win), node
    if minimax: #minimax = TRUE => minimizar
        moves = get_all_moves(node, PLAYER[0],game)
        if moves:
            best_move = None
            min_eval = float('inf')
            for move in moves:
                value = alpha_beta_pruning(move,depth-1,game,False,alpha,beta)[0]
                if value<min_eval:
                    min_eval = value
                    best_move = move
                beta = min(min_eval,beta)
                if alpha>=beta:
                    return min_eval,best_move
            return min_eval,best_move
        else:
            return node.evaluate(win),node
    else: #minimax = FALSE => maximizar
        moves = get_all_moves(node, PLAYER[1],game)
        if moves:
            best_move = None
            max_eval = float('-inf')
            for move in moves:
                value = alpha_beta_pruning(move,depth-1,game,True,alpha,beta)[0]
                if value>max_eval:
                    max_eval = value
                    best_move = move
                alpha = max(max_eval,alpha)
                if alpha>=beta:
                    return max_eval,best_move
            return max_eval,best_move
        else:
            return node.evaluate(win),node

def minimax_alg (node, depth, game, minimax = False):
    win = node.winner()
    if depth == 0 or win !=0:
        return node.evaluate(win), node
    if minimax: #minimax = TRUE => minimizar
        moves = get_all_moves(node, PLAYER[0],game)
        if moves:
            best_move = None
            min_eval = float('inf')
            for move in moves:
                value = minimax_alg(move,depth-1,game,False)[0]
                if value<min_eval:
                    min_eval = value
                    best_move = move
            return min_eval,best_move
        else:
            return node.evaluate(win),node
    else: #minimax = FALSE => maximizar
        moves = get_all_moves(node, PLAYER[1],game)
        if moves:
            best_move = None
            max_eval = float('-inf')
            for move in moves:
                value = minimax_alg(move,depth-1,game,True)[0]
                if value>max_eval:
                    max_eval = value
                    best_move = move
            return max_eval,best_move
        else:
            return node.evaluate(win),node

def simulate_move (piece, move, board, game, skip):
    board.move(piece,move[0],move[1])
    if skip:
        board.remove(skip)
    return board

def get_all_moves(board, color, game):
    moves = []

    for piece in board.get_all_pieces(color):
        valid_moves = board.get_valid_moves(piece)
        for move, skip in valid_moves.items():
            temp_board = deepcopy(board)
            temp_piece = temp_board.get_piece(piece.row, piece.col)
            new_board = simulate_move(temp_piece,move,temp_board, game, skip)
            moves.append(new_board)
    return moves





