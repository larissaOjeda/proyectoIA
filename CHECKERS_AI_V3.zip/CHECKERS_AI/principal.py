#Importamos los modulos necesarios
import pygame
import time
from checkers.constantes import *
from checkers.board import Board
from checkers.game import Game
from algoritmos import alpha_beta_pruning,minimax_alg,negamax
#Inicializamos la ventana
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
FPS = 30
#Titulo de la ventana
pygame.display.set_caption('Damas')

# Posición del mouse
def get_pos_from_mouse(pos):
    x,y= pos
    row= y // SQUARE_SIZE
    col= x// SQUARE_SIZE
    return row, col

#Método para iniciar el juego
def main():
    #event LOOP

    run=True
    #determinar fps
    clock=pygame.time.Clock()

    game=Game(WIN)

    while run:
        clock.tick(FPS)
        if game.turn == RED:
            start = time.time()
            value, new_board = alpha_beta_pruning(game.get_board(),5,game)
            #value,new_board = minimax_alg(game.get_board(),5,game)
            game.ai_move(new_board)
            end = time.time()
            print(end-start)
            
        if game.winner() != 0:
            print(game.winner())
            run = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run=False

            if event.type == pygame.MOUSEBUTTONDOWN:
                pos= pygame.mouse.get_pos()
                row, col= get_pos_from_mouse(pos)
                game.select(row, col)
        game.update()
    pygame.quit()  

main() 